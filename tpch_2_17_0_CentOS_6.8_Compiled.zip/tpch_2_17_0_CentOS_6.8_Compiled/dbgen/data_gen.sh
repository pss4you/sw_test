sqlldr userid=testuser/testuser@210.104.181.119:1521/ORA12R2 control=customer.tbl
sqlldr userid=testuser/testuser@210.104.181.119:1521/ORA12R2 control=lineitem.tbl
sqlldr userid=testuser/testuser@210.104.181.119:1521/ORA12R2 control=nation.tbl
sqlldr userid=testuser/testuser@210.104.181.119:1521/ORA12R2 control=orders.tbl
sqlldr userid=testuser/testuser@210.104.181.119:1521/ORA12R2 control=part.tbl
sqlldr userid=testuser/testuser@210.104.181.119:1521/ORA12R2 control=partsupp.tbl
sqlldr userid=testuser/testuser@210.104.181.119:1521/ORA12R2 control=region.tbl
sqlldr userid=testuser/testuser@210.104.181.119:1521/ORA12R2 control=supplier.tbl
